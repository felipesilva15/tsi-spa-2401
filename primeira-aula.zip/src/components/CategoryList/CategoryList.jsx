import axios from 'axios';
import React from "react";

const baseURL = 'http://195.35.40.172:9101/api'

export default function CategoryList() {
  const [categories, setCategories] = React.useState(null);

  React.useEffect(() => {
    axios.get(`${baseURL}/category`).then((response) => {
      setCategories(response.data);
    });
  }, []);

  if (!categories)
    return null;

  const categoryList = categories.map(category => 
    <tr>
      <td>{category.CATEGORIA_ID}</td>
      <td>{category.CATEGORIA_NOME}</td>
      <td>{category.CATEGORIA_DESC}</td>
    </tr>
  );

  return (
    <table>
      <tr>
        <th>#</th>
        <th>Categoria</th>
        <th>Descrição</th>
      </tr>
      {categoryList}
    </table>
  );
}