export default function MyFirstComponent() {
  return (
    <div>
      <p>Meu primeiro component!</p>
    </div>
 );
}