const list = [
  {id: 1, name: 'Leão'},
  {id: 2, name: 'Tigre'},
  {id: 3, name: 'Pinguim'}
];

export default function AnimalList() {
  const listItems = list.map(animal => 
    <li
      key={animal.id}
    >
      {animal.name}
    </li>
  );

  return (
    <ul>{listItems}</ul>
  );
}