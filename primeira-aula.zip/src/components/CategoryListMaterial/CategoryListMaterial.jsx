import axios from 'axios';
import * as React from 'react';
import { DataGrid } from '@mui/x-data-grid';
import CheckIcon from '@mui/icons-material/Check';

const baseURL = 'http://195.35.40.172:9101/api';

const columns = [
  { field: 'id', headerName: 'ID', width: 70 },
  { field: 'name', headerName: 'Category', width: 130 },
  { field: 'description', headerName: 'Description', width: 300 },
  { field: 'active', headerName: 'Active', width: 180 }
];

export default function CategoryListMaterial() {
  const [categories, setCategories] = React.useState(null);

  React.useEffect(() => {
    axios.get(`${baseURL}/category`).then((response) => {
      setCategories(response.data);
    });
  }, []);

  if (!categories)
    return null;

  const rows = categories.map(category => {
    return {
        id: category.CATEGORIA_ID,
        name: category.CATEGORIA_NOME,
        description: category.CATEGORIA_DESC,
        active: category.CATEGORIA_ATIVO == 1 ? <CheckIcon/>: null
    }
  })

  return (
    <div style={{ height: '100%', width: '100%' }}>
      <DataGrid
        rows={rows}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: { page: 0, pageSize: 12 },
          },
        }}
        loading={rows.length === 0}
        pageSizeOptions={[5, 10]}
        checkboxSelection
        disableRowSelectionOnClick
      />
    </div>
  );
}