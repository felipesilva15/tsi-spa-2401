import { Button } from "@mui/material";

export default function AppBar() {
  function hello () {
    alert('Hello User! 👋');
  }

  return (
    <>
      <Button variant="contained" onClick={hello}>
        Click here
      </Button>
    </>
  );
} 