import AnimalList from "./components/AnimalList/AnimalList";
import AppBar from "./components/AppBar/AppBar";
import CategoryListMaterial from "./components/CategoryListMaterial/CategoryListMaterial";
import MyFirstComponent from "./components/MyFirstComponent/MyFirstComponent";

function App() {
  return (
    <div>
      <h1>React APP</h1>

      <h2>Button Material</h2>
      <AppBar />
      <br></br>

      <h2>First component</h2>
      <MyFirstComponent />
      <br></br>

      <h2>Lista de animais</h2>
      <AnimalList />
      <br></br>

      <h2>Lista de categorias</h2>
      <CategoryListMaterial />
    </div>
  );
}

export default App;
